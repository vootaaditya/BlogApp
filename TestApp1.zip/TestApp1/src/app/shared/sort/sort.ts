import { Pipe, PipeTransform}  from '@angular/core';

@Pipe({
  name: "arraySort"
})
export class arraySortPipe implements PipeTransform  {
  transform(array: Array<string>, args: string): Array<string> {
    if(array){
    array.sort((a: any, b: any) => {
      debugger;
      if (a.publish_date < b.publish_date) {
        return 1;
      } else if (a.publish_date > b.publish_date) {
        return -1;
      } else {
        return 0;
      }
    });
    return array;
    }
  }
}
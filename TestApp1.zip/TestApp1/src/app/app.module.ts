import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome/welcome.component';
import { blogModule } from './blogs/blog.module';
import { blogFilterPipe } from './blogs/blog-filter.pipe';
import { arraySortPipe } from 'app/shared/sort/sort'

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    blogModule,
    RouterModule.forRoot([
            {path:'welcome',component:WelcomeComponent},
            {path:'',redirectTo:'welcome',pathMatch:'full'},
            {path:'**',redirectTo:'welcome',pathMatch:'full'},
    ])
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

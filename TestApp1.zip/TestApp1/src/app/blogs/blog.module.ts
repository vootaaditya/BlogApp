import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import  { blogListComponent } from './blog-list/blog-list.component'
import { blogService } from './service';
import { blogFilterPipe } from './blog-filter.pipe';
import { blogDetailComponent } from './blog-detail/blog-detail.component'
import { arraySortPipe } from 'app/shared/sort/sort'

@NgModule({
    declarations:[
        blogListComponent,
        blogFilterPipe,
        blogDetailComponent,
        arraySortPipe
    ],
    imports:[
        FormsModule,
        CommonModule,
        RouterModule.forChild([
            {path:'blog', component: blogListComponent},
            {path:'blog/:id', canActivate:[], component: blogDetailComponent }
        ])
    ],
    providers:[
        blogService,
        blogFilterPipe,
        arraySortPipe
    ]
})

export class blogModule{

}

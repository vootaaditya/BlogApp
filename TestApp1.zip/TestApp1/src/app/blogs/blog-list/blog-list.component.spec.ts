/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { blogListComponent } from './blog-list.component';

describe('blogListComponent', () => {
  let component: blogListComponent;
  let fixture: ComponentFixture<blogListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ blogListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(blogListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { IPost } from 'app/blogs/blog';
import { blogService } from 'app/blogs/service'

@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html'
})

export class blogListComponent implements OnInit {

  constructor(private _blogService: blogService) {

   }

   posts : IPost[]; 
   errorMessage : string;
   filterText : string;
    ngOnInit() {
       this._blogService.getblogs().subscribe(
         prods=>{
          debugger;
           this.posts = prods
          },
         error=> this.errorMessage=<any>error);

    }


}

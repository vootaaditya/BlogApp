import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IPost, IComment , Comment } from 'app/blogs/blog';
import { blogService } from 'app/blogs/service';
import { Observable } from 'rxjs/observable';

@Component({
  selector: 'app-blog-detail',
  templateUrl: './blog-detail.component.html'
})
export class blogDetailComponent implements OnInit {

  pageTitle: string = "";
  post: IPost;
  comments: IComment[];
  newComment : IComment = new  Comment();
  //@Input() public blog: Observable<IPost>;

  blogs: IPost[];
  errorMessage: string;
  constructor(private _activeRoute: ActivatedRoute, private _router: Router, private _blogService: blogService) {
  }

  onBack(): void {
    this._router.navigate(["/blog"]);
  }
  addComment(): void {
    debugger;
    if(!this.newComment.user){
      this.newComment.user = "Anonymous";
    }
    this.comments.push(this.newComment);
    this.newComment= new Comment();
    this.newComment.postId = this.post.id;
    this.newComment.content = '';
}

  ngOnInit() {
    let id = +this._activeRoute.snapshot.params['id'];
    this.pageTitle += `:${id}`;
    this._blogService.getblog(id).subscribe(prod => this.onSuccess(prod),
      error => this.errorMessage = <any>error);
    console.log(this.post)
  }

  onSuccess(_post: IPost): void {
    debugger;
    console.log("got details: " + _post);
    this.post = _post;
    this.newComment.postId =_post.id;
    this.newComment.content ="";
    this._blogService.getComment(_post.id).subscribe(cmnt => this.onCmntRetriveSuccess(cmnt),
      error => this.errorMessage = <any>error);
  }

  onCmntRetriveSuccess(_comments: IComment[]): void {
    debugger;
    console.log("got details: " + _comments);
    this.comments =_comments.filter(x => x.postId === this.post.id);
    
  }
}

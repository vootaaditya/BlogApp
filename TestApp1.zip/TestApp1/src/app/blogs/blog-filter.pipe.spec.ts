/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { blogFilterPipe } from './blog-filter.pipe';

describe('blogFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new blogFilterPipe();
    expect(pipe).toBeTruthy();
  });
});

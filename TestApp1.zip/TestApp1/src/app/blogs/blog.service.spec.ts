/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { blogService } from './service';

describe('blogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [blogService]
    });
  });

  it('should ...', inject([blogService], (service: blogService) => {
    expect(service).toBeTruthy();
  }));
});

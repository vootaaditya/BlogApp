import { Pipe, PipeTransform } from '@angular/core';
import { IPost } from './blog'

@Pipe({
  name: 'blogFilter'
})
export class blogFilterPipe implements PipeTransform {

  transform(value: IPost [], filterBy: string): IPost [] {
    filterBy= filterBy? filterBy.toLocaleLowerCase() :null;
    return filterBy ? value.filter((prod : IPost) =>
                                    prod.title.toLocaleLowerCase().indexOf(filterBy) !== -1) : value;
  }

}

import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http'
import { Observable } from 'rxjs/Observable'

import 'rxjs/add/operator/map'
import 'rxjs/add/operator/do'
import 'rxjs/add/operator/catch'
import {IPost, IComment} from './blog'

@Injectable()
export class blogService {

  private _url="api/blogs/blogs.json"
  private _commentsUrl="api/blogs/comments.json"
  constructor(private _http : Http) {

   }

    getblogs(): Observable<IPost[]>{
      return this._http.get(this._url).
                  map((response: Response)=> <IPost[]> response.json()).
                  do(data=> console.log('All: ' + JSON.stringify(data))).
                  catch(this.handleError);
   }

    getblog(id : number): Observable<IPost>{
      return this._http.get(this._url).
                  map((response: Response)=> <IPost> response.json().find(x => x.id === id)).
                  do(data=> console.log('All: ' + JSON.stringify(data))).
                  catch(this.handleError);
   }

    getComment(postId : Number): Observable<IComment[]>{
      return this._http.get(this._commentsUrl).
                  map((response: Response)=> <IComment> response.json()).
                  do(data=> console.log('All: ' + JSON.stringify(data))).
                  catch(this.handleError);
   }
   

   private handleError(error: Response){
      console.log(error);
      return Observable.throw(error.json().error || 'server error');
   }

}

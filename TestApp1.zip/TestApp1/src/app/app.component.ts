import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Blog Catalog';
  pages=[
       {"url":"welcome","name":"Welcome"},
       {"url":"blog","name":"Blogs"}
      ];
}
